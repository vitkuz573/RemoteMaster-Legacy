﻿module.exports = {
    content: ['./**/*.cshtml', './**/*.razor'],
    darkMode: 'class',
    theme: {
        extend: {},
    },
    variants: {
        extend: {
        },
    },
    plugins: [],
}
