﻿// Copyright © 2023 Vitaly Kuzyaev. All rights reserved.
// This file is part of the RemoteMaster project.
// Licensed under the GNU Affero General Public License v3.0.

using System.Diagnostics;
using System.IO;
using System.ServiceProcess;
using RemoteMaster.Agent.Abstractions;
using RemoteMaster.Agent.Core.Abstractions;
using RemoteMaster.Agent.Models;
using RemoteMaster.Shared.Abstractions;
using RemoteMaster.Shared.Models;

namespace RemoteMaster.Agent.Services;

public class AgentServiceManager : IAgentServiceManager
{
    public event Action<string, MessageType> MessageReceived;

    private readonly IRegistratorService _registratorService;
    private readonly IServiceManager _serviceManager;
    private readonly IConfigurationService _configurationService;

    private readonly IServiceConfig _agentConfig;

    private const string MainAppName = "RemoteMaster";
    private const string SubAppName = "Agent";

    public AgentServiceManager(IRegistratorService registratorService, IServiceManager serviceManager, IConfigurationService configurationService, IDictionary<string, IServiceConfig> configs)
    {
        if (configs == null)
        {
            throw new ArgumentNullException(nameof(configs));
        }

        _registratorService = registratorService;
        _serviceManager = serviceManager;
        _configurationService = configurationService;
        _agentConfig = configs["agent"];
    }

    public async Task InstallOrUpdate(ConfigurationModel configuration, string hostName, string ipv4Address, string macAddress)
    {
        try
        {
            var directoryPath = GetDirectoryPath();

            if (_serviceManager.IsServiceInstalled(_agentConfig.Name))
            {
                using var serviceController = new ServiceController(_agentConfig.Name);

                if (serviceController.Status != ServiceControllerStatus.Stopped)
                {
                    _serviceManager.StopService(_agentConfig.Name);
                }

                CopyToTargetPath(directoryPath);
            }
            else
            {
                CopyToTargetPath(directoryPath);
                var agentPath = Path.Combine(directoryPath, $"{MainAppName}.{SubAppName}.exe");
                _serviceManager.InstallService(_agentConfig, agentPath);
            }

            _serviceManager.StartService(_agentConfig.Name);

            MessageReceived?.Invoke($"{_agentConfig.Name} installed and started successfully.", MessageType.Information);

            var registerResult = await _registratorService.RegisterAsync(configuration, hostName, ipv4Address, macAddress);

            if (!registerResult)
            {
                MessageReceived?.Invoke("Computer registration failed.", MessageType.Error);
            }
        }
        catch (Exception ex)
        {
            MessageReceived?.Invoke($"An error occurred: {ex.Message}", MessageType.Error);
        }
    }

    public async Task Uninstall(ConfigurationModel configuration, string hostName)
    {
        try
        {
            if (_serviceManager.IsServiceInstalled(_agentConfig.Name))
            {
                _serviceManager.StopService(_agentConfig.Name);
                _serviceManager.UninstallService(_agentConfig.Name);

                await Task.Delay(TimeSpan.FromSeconds(30));

                foreach (var process in Process.GetProcessesByName("RemoteMaster.Client"))
                {
                    process.Kill();
                }

                DeleteFiles();

                MessageReceived?.Invoke($"{SubAppName} Service uninstalled successfully.", MessageType.Information);
            }
            else
            {
                MessageReceived?.Invoke($"{SubAppName} Service is not installed.", MessageType.Information);
            }

            if (!await _registratorService.UnregisterAsync(configuration, hostName))
            {
                MessageReceived?.Invoke("Computer unregistration failed.", MessageType.Error);
            }
        }
        catch (Exception ex)
        {
            MessageReceived?.Invoke($"An error occurred: {ex.Message}", MessageType.Error);
        }
    }

    private static string GetDirectoryPath()
    {
        var programFilesPath = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);

        return Path.Combine(programFilesPath, MainAppName, SubAppName);
    }

    private void CopyToTargetPath(string targetDirectoryPath)
    {
        if (!Directory.Exists(targetDirectoryPath))
        {
            Directory.CreateDirectory(targetDirectoryPath);
        }

        var targetExecutablePath = Path.Combine(targetDirectoryPath, $"{MainAppName}.{SubAppName}.exe");

        try
        {
            File.Copy(Environment.ProcessPath!, targetExecutablePath, true);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException($"Failed to copy the executable to {targetExecutablePath}. Details: {ex.Message}", ex);
        }

        var configName = _configurationService.GetConfigurationFileName();
        var sourceConfigPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory!, configName);
        var targetConfigPath = Path.Combine(targetDirectoryPath, configName);

        if (File.Exists(sourceConfigPath))
        {
            try
            {
                File.Copy(sourceConfigPath, targetConfigPath, true);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Failed to copy the configuration file to {targetConfigPath}.", ex);
            }
        }
    }

    private void DeleteFiles()
    {
        var mainDirectoryPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), MainAppName);
        var subAppNames = new[] { SubAppName, "Client" };

        foreach (var subAppName in subAppNames)
        {
            var directoryPath = Path.Combine(mainDirectoryPath, subAppName);

            if (Directory.Exists(directoryPath))
            {
                try
                {
                    Directory.Delete(directoryPath, true);
                    MessageReceived?.Invoke($"{subAppName} files deleted successfully.", MessageType.Information);
                }
                catch (Exception ex)
                {
                    MessageReceived?.Invoke($"Deleting {subAppName.ToLower()} files failed: {ex.Message}", MessageType.Error);
                }
            }
        }
    }
}