﻿// Copyright © 2023 Vitaly Kuzyaev. All rights reserved.
// This file is part of the RemoteMaster project.
// Licensed under the GNU Affero General Public License v3.0.

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using RemoteMaster.Agent.Core.Abstractions;
using RemoteMaster.Agent.Core.Services;
using Serilog;

namespace RemoteMaster.Agent.Core.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddCoreServices(this IServiceCollection services)
    {
        var serilogLogger = new LoggerConfiguration()
            .MinimumLevel.Debug()
            .WriteTo.Console()
            .WriteTo.File(@"C:\ProgramData\RemoteMaster\Agent\RemoteMaster_Agent.log", rollingInterval: RollingInterval.Day)
            .CreateLogger();

        services.AddLogging(builder =>
        {
            builder.AddConsole().AddDebug();
            builder.AddSerilog(serilogLogger);
            builder.SetMinimumLevel(LogLevel.Debug);
        });

        services.AddSingleton<IRegistratorService, RegistratorService>();
        services.AddSingleton<IConfigurationService, ConfigurationService>();
        services.AddSingleton<IHostInfoService, HostInfoService>();

        services.AddSignalR();

        return services;
    }
}
